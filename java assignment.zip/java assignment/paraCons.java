// this question is currently invalid
class paraCons{
    public static void main(String[] args) {
        
    }
}
class test{

}